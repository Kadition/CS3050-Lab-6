For task 1.1, use the provided csvs with the commands in the header of route_planner_task1_1.py
For task 1.2, use the commands in the header of route_planner_task1_2.py